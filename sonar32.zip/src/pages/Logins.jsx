import React from 'react';
import Button from 'react-bootstrap/Button';
 
const Login = () => (
    <>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js"></script>

    <div class="container-login">
    <div class="content-login"> 
    <h1>LOGIN</h1> 
   			<input class="input-login" placeholder="usuario"></input>
   			<input class="input-login" placeholder="contraseña" type="password"></input>
   			<div class="content-footer-login"> 
   			<button class="btn">Entrar</button> 
   			</div> 
   	 	<hr/> 
   	 	<div> <a href="Flogin"> <button class="btn-login btn-fb btn-primary">FACEBOOK</button></a> 
            <a href="Flogin"> <button class="btn-login btn-g btn-primary">GOOGLE</button> </a> 
      </div> 
   	 </div> 
   	 </div> 
    </>
)  

export default Login; 